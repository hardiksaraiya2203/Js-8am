export const handleCheckbox = () =>{
    let subCourse = document.querySelectorAll('.subCourse')
    let lang1 = document.querySelectorAll('.language1')
    let lang2 = document.querySelectorAll('.language2')

    console.log(subCourse)
    console.log(lang1)
    console.log(lang2)
}